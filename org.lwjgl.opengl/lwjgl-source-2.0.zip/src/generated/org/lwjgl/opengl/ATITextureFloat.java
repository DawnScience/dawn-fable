/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class ATITextureFloat {
	/**
	 * Accepted by the &lt;internalFormat&gt; parameter of TexImage1D,
	 * TexImage2D, and TexImage3D:
	 */
	public static final int GL_RGBA_FLOAT32_ATI = 0x8814;
	public static final int GL_RGB_FLOAT32_ATI = 0x8815;
	public static final int GL_ALPHA_FLOAT32_ATI = 0x8816;
	public static final int GL_INTENSITY_FLOAT32_ATI = 0x8817;
	public static final int GL_LUMINANCE_FLOAT32_ATI = 0x8818;
	public static final int GL_LUMINANCE_ALPHA_FLOAT32_ATI = 0x8819;
	public static final int GL_RGBA_FLOAT16_ATI = 0x881a;
	public static final int GL_RGB_FLOAT16_ATI = 0x881b;
	public static final int GL_ALPHA_FLOAT16_ATI = 0x881c;
	public static final int GL_INTENSITY_FLOAT16_ATI = 0x881d;
	public static final int GL_LUMINANCE_FLOAT16_ATI = 0x881e;
	public static final int GL_LUMINANCE_ALPHA_FLOAT16_ATI = 0x881f;

	private ATITextureFloat() {
	}

}

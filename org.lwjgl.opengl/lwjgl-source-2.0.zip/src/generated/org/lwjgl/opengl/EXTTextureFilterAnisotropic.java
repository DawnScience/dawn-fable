/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class EXTTextureFilterAnisotropic {
	public static final int GL_TEXTURE_MAX_ANISOTROPY_EXT = 0x84fe;
	public static final int GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT = 0x84ff;

	private EXTTextureFilterAnisotropic() {
	}

}

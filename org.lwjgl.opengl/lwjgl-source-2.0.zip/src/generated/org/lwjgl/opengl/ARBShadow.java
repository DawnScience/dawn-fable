/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class ARBShadow {
	public static final int GL_TEXTURE_COMPARE_MODE_ARB = 0x884c;
	public static final int GL_TEXTURE_COMPARE_FUNC_ARB = 0x884d;
	public static final int GL_COMPARE_R_TO_TEXTURE_ARB = 0x884e;

	private ARBShadow() {
	}

}

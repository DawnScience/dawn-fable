/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class EXTSeparateSpecularColor {
	public static final int GL_SINGLE_COLOR_EXT = 0x81f9;
	public static final int GL_SEPARATE_SPECULAR_COLOR_EXT = 0x81fa;
	public static final int GL_LIGHT_MODEL_COLOR_CONTROL_EXT = 0x81f8;

	private EXTSeparateSpecularColor() {
	}

}

/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;
import org.lwjgl.BufferChecks;
import org.lwjgl.NondirectBufferWrapper;
import java.nio.*;

public final class EXTTextureRectangle {
	public static final int GL_TEXTURE_RECTANGLE_EXT = 0x84f5;
	public static final int GL_TEXTURE_BINDING_RECTANGLE_EXT = 0x84f6;
	public static final int GL_PROXY_TEXTURE_RECTANGLE_EXT = 0x84f7;
	public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_EXT = 0x84f8;

	private EXTTextureRectangle() {
	}

}
